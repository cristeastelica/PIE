<?php $servername = "localhost";
$username = "admin";
$password = "admin123";
$myDB="7YNzXacPRV";

define("DB_DSN", "mysql:host=$servername;dbname=$myDB");
define("DB_USER", "admin");
define("DB_PASS", "admin123");
?>